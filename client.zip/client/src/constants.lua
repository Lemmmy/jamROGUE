return {
    server = "http://localhost:3000/"
}